from __future__ import annotations

import base64
import json
import os
import sys
import uuid
from typing import Any, Dict, Optional

from errors import OrderError, error_body, internal_error, json_default, service_unavailable, unauthorized, validation_error
from identity import IdentityError, extract_identity
from order_service import create_order_service
from validation import validate_list_params, validate_order_id, validate_status_update_body

JSON_HEADERS = {"Content-Type": "application/json"}

SQS_QUEUE_URL = os.environ.get("SQS_QUEUE_URL")

# Bestehenden Helper wiederverwenden (zentral in errors.json_default).
_json_default = json_default

def _get_sqs_client():
    import boto3
    return boto3.client('sqs', region_name=os.environ.get('AWS_REGION', 'eu-central-1'))

def _send_to_sqs(order_id: str) -> bool:
    if not SQS_QUEUE_URL:
        print("SQS_QUEUE_URL not configured")
        return False
    try:
        sqs = _get_sqs_client()
        message = {
            "orderId": order_id,
            "status": "CONFIRMED",
            "metadata": {"reason": "order_created"}
        }
        sqs.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps(message),
            MessageAttributes={
                "orderId": {
                    "StringValue": order_id,
                    "DataType": "String"
                }
            }
        )
        print(f"Sent order {order_id} to SQS")
        return True
    except Exception as e:
        print(f"Failed to send to SQS: {e}")
        return False

def parse_body(event: Dict[str, Any]) -> Any:
    body = event.get("body")
    if body is None:
        return None
    raw = body
    if event.get("isBase64Encoded"):
        try:
            raw = base64.b64decode(body).decode("utf-8")
        except Exception as exc:
            raise validation_error("Request body must be valid JSON") from exc
    try:
        return json.loads(raw)
    except (ValueError, TypeError) as exc:
        raise validation_error("Request body must be valid JSON") from exc


def ok(status_code: int, payload: Any) -> Dict[str, Any]:
    return {
        "statusCode": status_code,
        "headers": JSON_HEADERS,
        "body": json.dumps(payload, separators=(",", ":"), default=_json_default),
    }


def fail(error: Any) -> Dict[str, Any]:
    if isinstance(error, OrderError):
        return {
            "statusCode": error.http_status,
            "headers": JSON_HEADERS,
            "body": json.dumps(error_body(error), separators=(",", ":"), default=_json_default),
        }
    print(f"Unexpected error: {error}", file=sys.stderr)
    err = internal_error()
    return {
        "statusCode": err.http_status,
        "headers": JSON_HEADERS,
        "body": json.dumps(error_body(err), separators=(",", ":"), default=_json_default),
    }


def route_key(event: Dict[str, Any]) -> str:
    route = event.get("routeKey")
    if route:
        return route
    method = event.get("httpMethod", "GET")
    path = event.get("rawPath", "/")
    return f"{method} {path}"


# Interne Privacy-Aktionen — ausschließlich per direktem Lambda-Invoke
# (IAM lambda:InvokeFunction) erreichbar. Es wird KEINE öffentliche
# API-Gateway-Route hinzugefügt. Jede Aktion läuft durch
# OrderService._require_privacy_auth (fail-closed).
_INTERNAL_PRIVACY_ACTIONS = ("privacy/inspect", "privacy/export", "privacy/erase")


def _handle_internal(service: Any, event: Dict[str, Any]) -> Dict[str, Any]:
    action = event.get("internalAction")
    if action not in _INTERNAL_PRIVACY_ACTIONS:
        return fail(validation_error(f"Unsupported internal action: {action}"))
    payload = event.get("payload") or {}
    auth_context = event.get("authContext")
    subject_id = payload.get("subjectId")
    options = payload.get("options")
    try:
        if action == "privacy/inspect":
            result = service.inspect_subject(subject_id, context=auth_context)
        elif action == "privacy/export":
            result = service.export_subject(subject_id, context=auth_context)
        else:
            result = service.erase_subject(subject_id, context=auth_context, options=options)
        return ok(200, result)
    except Exception as err:
        return fail(err)


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    table_name = os.environ.get("ORDERS_TABLE")
    if not table_name:
        return fail(internal_error("Lambda is not configured (ORDERS_TABLE missing)"))

    service = create_order_service(table_name=table_name)

    # Interner Aufrufweg (direkter Invoke, keine HTTP-Route).
    if isinstance(event, dict) and isinstance(event.get("internalAction"), str):
        return _handle_internal(service, event)

    # Public routes require a verified caller identity. Missing configuration is
    # a deployment error (503), never a reason to skip the check.
    expected_issuer = os.environ.get("ORDERS_COGNITO_ISSUER")
    expected_client_id = os.environ.get("ORDERS_COGNITO_CLIENT_ID")
    if not expected_issuer or not expected_client_id:
        print("Identity configuration missing (ORDERS_COGNITO_ISSUER/CLIENT_ID)")
        return fail(service_unavailable("Service is not configured"))

    try:
        identity = extract_identity(
            event,
            expected_issuer=expected_issuer,
            expected_client_id=expected_client_id,
        )
    except IdentityError as exc:
        print(f"Identity rejected: {exc.code}")
        return fail(unauthorized())

    try:
        route = route_key(event)

        if route == "POST /orders":
            order = service.create_order(parse_body(event), identity)
            order_id = order.get("orderId")
            # Agent orders are persisted only; dispatch is a separate gate
            # (A05). Sending them to the status-only retail worker would corrupt
            # their lifecycle, so the retail SQS path stays retail-only.
            if (order_id and SQS_QUEUE_URL
                    and order.get("orderType") != "agent.execution"):
                _send_to_sqs(order_id)
            return ok(201, order)

        if route == "GET /orders":
            params = validate_list_params(event.get("queryStringParameters"))
            result = service.list_orders(
                identity, params["limit"], params.get("nextToken"))
            return ok(200, result)

        if route == "GET /orders/{orderId}":
            path_params = event.get("pathParameters") or {}
            order_id = validate_order_id(path_params.get("orderId"))
            order = service.get_order(order_id, identity)
            return ok(200, order)

        if route == "PATCH /orders/{orderId}/status":
            path_params = event.get("pathParameters") or {}
            order_id = validate_order_id(path_params.get("orderId"))
            status = validate_status_update_body(parse_body(event))
            order = service.update_order_status(order_id, status, identity)
            return ok(200, order)

        return fail(validation_error(f"Unsupported route: {route}"))
    except Exception as err:
        return fail(err)
